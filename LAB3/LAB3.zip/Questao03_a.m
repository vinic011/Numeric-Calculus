%Questão 03 - (a)
A = [1 4 5 3; -2 0 4 1; 3 -3 1 0; 2 1 10 3.99999999];
b = [50; 90; 34; 2342];
resultado = Condicionamento_Refinamento(A,b)
valorCond = Condicionamento_Norma(A)