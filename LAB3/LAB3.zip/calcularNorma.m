function norma = calcularNorma(x)
    norma = max(sum(abs(x')));
end