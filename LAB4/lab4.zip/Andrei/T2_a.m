A = rand(100) + 100*eye(100);
b = rand(100, 1);
[dr1, dr2] = Tarefa2(A, b);