A = hilb(8);
b = rand(8, 1);
[dr1, dr2] = Tarefa2(A, b);