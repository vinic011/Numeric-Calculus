%Questão 01:
x = [179.9; 240.0; 113.5; 281.5; 186.0; 275.0; 281.5; 210.0; 210.0; ...
184.0; 186.5; 239.0; 185.0; 251.0; 180.0; 160.0; 255.0; 220.0; ...
160.0; 200.0; 265.0; 190.0; 150.5; 189.0; 157.0; 171.5; 157.0; ...
175.0; 159.0; 229.0];

y = [188.7; 220.4; 118.1; 232.4; 188.1; 240.1; 232.4; 211.8; 168.0; ...
180.3; 294.7; 209.2; 162.3; 236.8; 123.7; 191.7; 245.6; 219.3; ...
181.6; 177.4; 307.2; 229.7; 168.9; 194.4; 143.9; 201.4; 143.9; ...
181.0; 125.1; 195.3];

[a1, b1, r, R_L] = RegressaoLinear(x, y);
f = @(x)(a+b*x);
[a, b, c, R_Q] = AjusteParabola(x, y);
g = @(x)(a+b*x+c*(x^2));

figure; 
hold on;
plot(x, y, '*b');
grid;
fplot(f, [min(x), max(x)]);
fplot(g, [min(x), max(x)]);

xlabel('Sales Price')
ylabel('Assessed value')
legend('pontos', 'regressão linear', 'parábola de ajuste')
title('Assessed value x Sales Price');
