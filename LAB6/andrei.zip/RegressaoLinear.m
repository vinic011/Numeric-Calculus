function [a, b, r, R] = RegressaoLinear(x, y)
m = length(x);

A(1, 1) = m;
A(1, 2) = sum(x);
A(2, 1) = sum(x);
A(2, 2) = sum(x.^2);
z(1, 1) = sum(y);
z(2, 1) = x'*y;
c = A\z;
a = c(1);
b = c(2);

f_estimada = @(x)(a+b*x);
R = sum((f_estimada(x)-y).^2);
y_hat = ones(m, 1)*mean(y);
R_M = sum((y_hat-y).^2);
r = sqrt((R_M-R)/R_M);

figure
plot(x, y, '*')
hold on
fplot(f_estimada, [min(x), max(x)]);
xlabel('x');
ylabel('y');
legend('pontos', 'curva de ajuste');
title('Regressão Linear');

end