function Fv=funsys(t,Y)
Fv(1,1)=-0.5*Y(1);
Fv(2,1)= 4-0.3*Y(2)-0.1*Y(1);